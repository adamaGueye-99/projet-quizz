<?php
session_start();

    try{

        $bd= new PDO('mysql:host=localhost;dbname=quizz_projet;charset=utf8','root','');
        $bd-> setAttribute(PDO::ATTR_CASE, PDO::CASE_LOWER);// champs en minuscules
        $bd->setAttribute(PDO::ATTR_ERRMODE , PDO::ERRMODE_EXCEPTION); //exceptions

    }
    catch (Exeption $e){

        echo "Une erreur est survenue !";
        die();

    }

    if(isset($_GET['id']) AND $_GET['id'] > 0){

        $getid = intval($_GET['id']);
        $requser = $bd -> prepare("SELECT * FROM utilisateurs WHERE id = ?");
        $requser -> execute(array($getid));
        $userinfo = $requser -> fetch();

?>

<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8" />
        <title>Liste des joueurs </title>
        <link rel="stylesheet" type="text/css" href="assets/css/style.css">
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400&display=swap" rel="stylesheet">
    </head>
        
        
    <body>
        <div class="transparent">
        <header>
            <nav>
                <div class="logo"></div>
                <div class="titre">Le plaisir de jouer</div>
            </nav>
                    </header>
            <div class="container">
        <div class="box w92">
            <div class="head_box">
                                <p><br>Créer et paramétrer vos quizz</p>
                
<link rel="stylesheet" type="text/css" href="./assets/css/modal.css">
<div id="myModal" class="modal">

  
  <div class="modal-content">
    <div class="modal-header">
      <span class="close cl">&times;</span>
      <p class="big_font">Déconnexion!</p>
    </div>
    <div class="modal-body">
      <p class='col_r'> Etes vous surs de vouloir vous déconnecter?</p>
    </div>
    <div class="modal-footer ">
      <button class='close ipbtn col_r'> Annuler</button> <a id="href_id" href="index.php?origin=deconnexion"> <button name='submit' class="ipbtn float_r" ><a href="deconnexion.php"> Confirmer</a>  </button></a>
    </div>
  </div>

</div>                
                    <button class="ipbtn pos_abs float_r" id="myBtn" >Déconnexion</button>
          
            </div>
                   <link rel="stylesheet" type="text/css" href="assets/css/homeAdmin.css">
       <link rel="stylesheet" type="text/css" href="assets/css/styleCheck.css">
       <link rel="stylesheet" type="text/css" href="assets/css/styleCheckAdmin.css">
        
    <div class="body_box">
        <div class="box_menu_1">
            <div class="div_avatar_1">
                <div class="img_avatar_1">
                    <img class="w_70_h_70" alt="av" src="assets/icones/img5.jpg"/>
                </div>
                <div class="float_l ">
                    <br><br>
                    <a href="index.php?origin=admin&action=profilAdmin">
                        <div>&nbsp;&nbsp;&nbsp;<label class="lab_prenom "><?php echo $userinfo['prenom']; ?></label></div>
                        <div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<label class="lab_nom"><?php echo $userinfo['nom']; ?></label></div>
                    </a>
                </div>
            </div>
            <div class="div_menu"> 
           
                <a href="ListeQuestions.php?id=<?php echo $_GET['id']?>"><div class="li  sm_1" ><span>Liste Questions</span></div></a>
                <a href="CreerAdmin.php?id=<?php echo $_GET['id']?>"><div class="li  sm_2" >Créer Admin</div></a>
                <a href="ListeJoueurs.php?id=<?php echo $_GET['id']?>"><div class="li active sm_3" >Liste joueurs</div></a>
                <a href="CreerQuestions.php?id=<?php echo $_GET['id']?>"> <div class="li  sm_4 " >Créer Questions</div></a>
            </div>
        </div>

        <div class="rotate_page">
                
<link rel="stylesheet" type="text/css" href="./assets/css/modal.css">
<div id="myModal1" class="modal1">

  
  <div class="modal-content">
    <div class="modal-header">
      <p class="big_font" id="id_title">Changer Statut Joueur</p>
    </div>
    <div class="modal-body">
      <p class='col_r' id='id_msg'>Vous étes sur de vouloir  changer le statut du Joueur?</p>
    </div>
    <div class="modal-footer ">
      <button id='close1' class='close1 ipbtn col_r'> Annuler</button> <a id="ref_id" href="#"> <button name='submit' class="ipbtn float_r" >Confirmer</button></a>
    </div>
  </div>

</div>	<div class="contain_pl">
	    <h2 class="h2">Listes des joueurs par score</h2>
	    <div class="contain_sub">

      <table class="table">
					<caption> </caption>
				<tr><th scope="col">Nom</th><th scope="col">Prénom</th><th scope="col">Score</th></th>
										<tr><td style=' text-transform: uppercase;'>Fall</td><td style=' text-transform: capitalize;'>Alioune</td><td>90pts</td><td> <span onclick="removeUser(1)">&#x274C;</span> &nbsp;&nbsp;&nbsp;
						<span onclick='changeStatut(1);'>&#128272;</span>							</td></tr>
													<tr><td style=' text-transform: uppercase;'> Pereira</td><td style=' text-transform: capitalize;'>Abdoul khadre</td><td>76pts</td><td> <span onclick="removeUser(17)">&#x274C;</span> &nbsp;&nbsp;&nbsp;
            <span onclick='changeStatut(17);'>&#128272;</span>							</td></tr>
            <tr><td style=' text-transform: uppercase;'>diani<td style=' text-transform: capitalize;'>Alioune</td><td>50pts</td><td> <span onclick="removeUser(1)">&#x274C;</span> &nbsp;&nbsp;&nbsp;
						<span onclick='changeStatut(1);'>&#128272;</span>							</td></tr>
													<tr><td style=' text-transform: uppercase;'>gueye</td><td style=' text-transform: capitalize;'>Adama</td><td>46pts</td><td> <span onclick="removeUser(17)">&#x274C;</span> &nbsp;&nbsp;&nbsp;
            <span onclick='changeStatut(17);'>&#128272;</span>							</td></tr>
            <tr><td style=' text-transform: uppercase;'>Fall</td><td style=' text-transform: capitalize;'>rama</td><td>30pts</td><td> <span onclick="removeUser(1)">&#x274C;</span> &nbsp;&nbsp;&nbsp;
						<span onclick='changeStatut(1);'>&#128272;</span>							</td></tr>
													<tr><td style=' text-transform: uppercase;'>Vaz Pereira</td><td style=' text-transform: capitalize;'>Abdoul </td><td>26pts</td><td> <span onclick="removeUser(17)">&#x274C;</span> &nbsp;&nbsp;&nbsp;
            <span onclick='changeStatut(17);'>&#128272;</span>							</td></tr>
            <tr><td style=' text-transform: uppercase;'>SY</td><td style=' text-transform: capitalize;'>baila</td><td>10pts</td><td> <span onclick="removeUser(1)">&#x274C;</span> &nbsp;&nbsp;&nbsp;
						<span onclick='changeStatut(1);'>&#128272;</span>							</td></tr>
													<tr><td style=' text-transform: uppercase;'>ndiaye</td><td style=' text-transform: capitalize;'>manuel</td><td>6pts</td><td> <span onclick="removeUser(17)">&#x274C;</span> &nbsp;&nbsp;&nbsp;
						<span onclick='changeStatut(17);'>&#128272;</span>							</td></tr>
        
                      <span onclick='changeStatut(1);'>&#128272;</span>							</td></tr>
													<tr><td style=' text-transform: uppercase;'>Mamfoumby</td><td style=' text-transform: capitalize;'>Anges</td><td>2pts</td><td> <span onclick="removeUser(17)">&#x274C;</span> &nbsp;&nbsp;&nbsp;
						<span onclick='changeStatut(17);'>&#128272;</span>							</td></tr>
											</table>
	    </div>

        <div class="div_nav">
			
		                <a href='index.php?origin=admin&action=joueurs&p=2' class='ipbtn float_r'>Suivant</a>           
                     </div>
	</div>
  <script>
        
      
        var modal1 = document.getElementById("myModal1");
      
        var btn1 = document.getElementById("myBtn1");
      
        var span1 = document.getElementById("close1");
        
      
        span1.onclick = function() {
         modal1.style.display = "none";
        }
        
        
        window.onclick = function(event) {
         if (event.target == modal1) {
           modal1.style.display = "none";
         }
        }
        
        
        
        function changeStatut(ind)
        {
           document.getElementById('ref_id').href="index.php?origin=admin&changeStatut="+ind;
           
           modal1.style.display = "block";
        
        document.getElementById('id_title').innerHTML='Changer Statut';
        document.getElementById('id_msg').innerHTML="Vous Ã©tes sur de changer le statut du Joueur";
        
        }
        
        function removeUser(ind)
        {
           document.getElementById('ref_id').href="index.php?origin=admin&removePlayer="+ind;
           
           modal1.style.display = "block";
        
        document.getElementById('id_title').innerHTML='ALERT!!';
        document.getElementById('id_msg').innerHTML="Vous etes  sur de vouloir supprimer cet utilisateur??";
        
        }
            </script>        </div>
            </div>
                </div>
            </div>
        
            <script>
                
      
        var modal = document.getElementById("myModal");
        
      
        var btn = document.getElementById("myBtn");
        
    
        var span = document.getElementsByClassName("close")[1];
    
        var span1 = document.getElementsByClassName("close")[0];
        
      
        btn.onclick = function() {
          modal.style.display = "block";
        }
        
      
        span1.onclick = function() {
          modal.style.display = "none";
        }
    
        span.onclick = function() {
          modal.style.display = "none";
        }
        
  
        window.onclick = function(event) {
          if (event.target == modal) {
            modal.style.display = "none";
          }
        }
            </script>
        <div>
    </body>
</html>
<?php

}

?>