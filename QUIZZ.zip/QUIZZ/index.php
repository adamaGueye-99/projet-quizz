<?php
session_start();

    try{

        $bd= new PDO('mysql:host=localhost;dbname=quizz_projet;charset=utf8','root','');
        $bd-> setAttribute(PDO::ATTR_CASE, PDO::CASE_LOWER);// champs en minuscules
        $bd->setAttribute(PDO::ATTR_ERRMODE , PDO::ERRMODE_EXCEPTION); //exceptions

    }
    catch (Exeption $e){

        echo "Une erreur est survenue !";
        die();

    }

    if(isset($_POST['connexion'])){

        $loginConnect= htmlspecialchars($_POST['username']);
        $mdpConnect= sha1($_POST['password']);

        if(!empty($loginConnect) AND !empty($mdpConnect)){

            $requser = $bd ->prepare("SELECT * FROM utilisateurs WHERE login= ? AND password= ?");
            $requser->execute(array($loginConnect, $mdpConnect));
            $userexist = $requser->rowCount();

            if($userexist == 1){

                $userinfo = $requser->fetch();
                $_SESSION['id'] = $userinfo['id'];
                $_SESSION['prenom'] = $userinfo['prenom'];
                $_SESSION['nom'] = $userinfo['nom'];
                $_SESSION['login'] = $userinfo['login'];


                header('Location: CreerAdmin.php?id='.$_SESSION['id']);
            }
            else{

                $erreur = "Login et/ou mot de passe incorrect !";
            }
        }

    }

?>




<!DOCTYPE html>

<head>
        <meta charset="utf-8" />
        <title>Page de connexion</title>
        <link rel="stylesheet" type="text/css" href="assets/css/style.css">
    </head>
        <script>

     window.onload = function() {
            setTimeout(function(){ 
                    document.getElementById("alert").style.display='none';
                }, 3000);
            }
        </script>
    <body>
        <div class="transparent">
        <header>
            <nav>
                <div class="logo"></div>
                <div class="titre">Le plaisir de jouer</div>
            </nav>
                    </header>
        
            <p>
                <br><br>
            </p>
            <div class="box w50">
                <div class="head_box">
                   <span class="labhead">Login Form</span>
                </div>
                <div class="body_box">
                    <form action="" id="form_login" method="post">
                        <div class="div_input"><input class="iptxt iplogin" error="error-1" type="text" name="username" placeholder="Login"value="" ><div id="error-1" class="input_alert"></div> </div>
                        <div class="div_input "><input class="iptxt ippwd" error="error-2" type="password" name="password" placeholder="Password" ><div id="error-2" class="input_alert"></div> </div><br>
                        <?php
                            if(isset($erreur)){
                                echo "<font color='red'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;".$erreur."</font>";
                            }
                        ?><br>
                        <div class="div_input"><Button class="ipbtn" type="submit" name="connexion" > Connexion</button>&nbsp;&nbsp;&nbsp;<a href=pages/inscription.php><small>s'inscrire pour jouer</small></a></div>
                    </form>
                </div>
            </div>
            <script>
                const inputs = document.getElementsByTagName("input");
                for(input of inputs)
                {
                    input.addEventListener("keyup",function(e)
                    {
                        if(e.target.hasAttribute("error"))
                        {
                            var idDivError=e.target.getAttribute("error");
                            document.getElementById(idDivError).innerText="";
                        }
                    })
                }

                document.getElementById("form_login").addEventListener("submit",function(e)
                {   
                    const inputs=document.getElementsByTagName("input");
                    var error=false;
                    for(input of inputs)
                    {
                        if(input.hasAttribute("error"))
                        {
                            var idDivError = input.getAttribute("error");
                            if(!input.value.trim())
                            {
                                input.value="";
                                document.getElementById(idDivError).innerText='ce champ est obligatoitre';
                                error=true;
                            }
                        }

                    }
                    if(error)
                    {
                        e.preventDefault();
                        return false;
                    }
                })
            </script>
        <div>
    </body>


</html>