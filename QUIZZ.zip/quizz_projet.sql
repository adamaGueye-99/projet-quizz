-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Mer 17 Juin 2020 à 10:24
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `quizz_projet`
--

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE IF NOT EXISTS `utilisateurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prenom` varchar(100) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `login` varchar(100) NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Contenu de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `prenom`, `nom`, `login`, `password`) VALUES
(1, 'Yaye', 'adama', 'adamaGueye-99', '$2y$10$TQsd50GvSApKFS9Xv4bpVeo77wgF7JlkWFBJJApkx9uBSjfp00fPG'),
(2, 'yaye adama', 'Gueye', 'adabbesh', '$2y$10$tHfs9HaJmLwvXxdjd3hYrOH2fVolloCuzOvkWrNLzlZFnztjeq54C'),
(3, 'Bamba', 'Gueye', 'babs', '$2y$10$aE1JPBqSHZeDs4l.VTmRbuEpGaMOwsirCVg4a0hzIC6DXIMOvQxqO'),
(4, 'Yaye adama', 'Gueye', 'bibi', 'a2be9b448cc1a650c6fac671486061ad3ca4ca49');

- Structure de la table `question`
--

DROP TABLE IF EXISTS `question`;
CREATE TABLE IF NOT EXISTS `question` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `reponses` varchar(100) NOT NULL,
  `nbrePoint` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=56 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `question`
--

INSERT INTO `question` (`id`, `question`, `type`, `reponses`, `nbrePoint`) VALUES
(43, '  Que signifie PHP ?', 'cm', 'Pretext Hypertext Procesor', 10),
(42, '  Que signifie PHP ?', 'cm', 'Hypertext Preprocessor', 10),
(41, '  Que signifie PHP ?', 'cm', 'Personnal Home Page', 10),
(40, 'HTML a Ã©tÃ© proposÃ© pour la premiÃ¨re fois lâ€™annÃ©e__', 'ct', '1990', 10),
(44, '  Que signifie PHP ?', 'cm', 'Preprocessor Home Page', 10),
(45, 'Le pays le plus peuplÃ© ?', 'cs', 'Chine', 20),
(46, 'Le pays le plus peuplÃ© ?', 'cs', 'SÃ©nÃ©gal', 20),
(47, 'Le pays le plus peuplÃ© ?', 'cs', 'Maroc', 20),
(48, 'Le pays le plus peuplÃ© ?', 'cs', 'Tunisie', 20),
(49, 'Si nous souhaitons dÃ©finir le style dâ€™un seule Ã©lÃ©ment, quel sÃ©lecteur css utiliserons-nous__ ', 'ct', 'id', 25),
(50, ' La balise HTML qui spÃ©cifie un style CSS intÃ©grÃ© dans un Ã©lÃ©ment est appelÃ©e___', 'ct', 'style', 21),
(51, '  le presidents du SÃ©nÃ©gal?', 'cs', 'Abdou Diouf', 100),
(52, '  le presidents du SÃ©nÃ©gal?', 'cs', 'Abdoulaye wade', 100),
(53, '  le presidents du SÃ©nÃ©gal?', 'cs', 'Bamba Fall', 100),
(54, '  le presidents du SÃ©nÃ©gal?', 'cs', 'Macky Sall', 100),
(55, 'la population du SÃ©nÃ©gal en 2018', 'ct', '14500000', 17);

-- --------------------------------------------------------

--
-
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
